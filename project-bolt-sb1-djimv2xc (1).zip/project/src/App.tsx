import { useState } from 'react';
import NavBar from './components/NavBar';
import Hero from './components/Hero';
import PackagesGrid from './components/PackagesGrid';
import Services from './components/Services';
import About from './components/About';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ModalBooking from './components/ModalBooking';
import { Package } from './data/packages';

function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);

  const handleBookPackage = (pkg: Package) => {
    setSelectedPackage(pkg);
    setIsModalOpen(true);
  };

  const handleBookNow = () => {
    const packagesSection = document.getElementById('packages');
    if (packagesSection) {
      packagesSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleViewPackages = () => {
    const packagesSection = document.getElementById('packages');
    if (packagesSection) {
      packagesSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <NavBar />
      <Hero onBookNow={handleBookNow} onViewPackages={handleViewPackages} />
      <PackagesGrid onBookPackage={handleBookPackage} />
      <Services />
      <About />
      <Testimonials />
      <Contact />
      <Footer />
      <ModalBooking
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        selectedPackage={selectedPackage}
      />
    </div>
  );
}

export default App;
