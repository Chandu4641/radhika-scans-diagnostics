import { useState } from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Heart, Eye, EyeOff } from 'lucide-react';
import { getRecentBookings } from '../utils/api';

export default function Footer() {
  const [showDebug, setShowDebug] = useState(false);
  const bookings = getRecentBookings();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">R</span>
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold text-white leading-tight">Radhika Scans</span>
                <span className="text-xs text-gray-400">& Diagnostics</span>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-4">
              Your trusted partner for accurate and affordable diagnostic services.
            </p>
            <div className="flex space-x-3">
              <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-400 transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-pink-600 transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors">
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => scrollToSection('home')} className="hover:text-blue-400 transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('packages')} className="hover:text-blue-400 transition-colors">
                  Health Packages
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('services')} className="hover:text-blue-400 transition-colors">
                  Services
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('about')} className="hover:text-blue-400 transition-colors">
                  About Us
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('contact')} className="hover:text-blue-400 transition-colors">
                  Contact
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Services</h3>
            <ul className="space-y-2 text-sm">
              <li>Blood Tests</li>
              <li>Radiology</li>
              <li>Ultrasound</li>
              <li>ECG</li>
              <li>X-Ray</li>
              <li>Health Checkups</li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Contact Info</h3>
            <ul className="space-y-2 text-sm">
              <li>123 Health Street, MG Road</li>
              <li>Bangalore, Karnataka 560001</li>
              <li className="pt-2">
                <a href="tel:+919876543210" className="hover:text-blue-400 transition-colors">
                  +91 98765 43210
                </a>
              </li>
              <li>
                <a href="mailto:info@radhikascans.com" className="hover:text-blue-400 transition-colors">
                  info@radhikascans.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-sm text-gray-400">
            © {new Date().getFullYear()} Radhika Scans & Diagnostics. All rights reserved.
          </p>
          <div className="flex items-center space-x-1 text-sm">
            <span className="text-gray-400">Made with</span>
            <Heart className="w-4 h-4 text-red-500 fill-current" />
            <span className="text-gray-400">for better health</span>
          </div>
        </div>

        <div className="mt-4 text-center">
          <button
            onClick={() => setShowDebug(!showDebug)}
            className="text-xs text-gray-600 hover:text-gray-400 transition-colors inline-flex items-center space-x-1"
          >
            {showDebug ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
            <span>{showDebug ? 'Hide' : 'Show'} Recent Bookings ({bookings.length})</span>
          </button>

          {showDebug && bookings.length > 0 && (
            <div className="mt-4 bg-gray-800 rounded-lg p-4 text-left max-w-2xl mx-auto">
              <h4 className="text-white font-bold mb-2 text-sm">Debug: Recent Bookings</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {bookings.map((booking: any, index: number) => (
                  <div key={index} className="text-xs bg-gray-900 p-2 rounded">
                    <div className="text-blue-400">{booking.bookingId}</div>
                    <div>{booking.name} - {booking.packageName}</div>
                    <div className="text-gray-500">{new Date(booking.timestamp).toLocaleString()}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </footer>
  );
}
