import { motion } from 'framer-motion';
import { Check, TrendingUp } from 'lucide-react';
import { Package } from '../data/packages';

interface PackageCardProps {
  package: Package;
  onBook: (pkg: Package) => void;
  index: number;
}

export default function PackageCard({ package: pkg, onBook, index }: PackageCardProps) {
  const discount = Math.round(((pkg.originalPrice - pkg.offerPrice) / pkg.originalPrice) * 100);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -8, transition: { duration: 0.2 } }}
      className={`bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all p-6 border-2 ${
        pkg.popular ? 'border-orange-500 relative' : 'border-gray-100'
      }`}
    >
      {pkg.popular && (
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
          <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center space-x-1">
            <TrendingUp className="w-3 h-3" />
            <span>Most Popular</span>
          </div>
        </div>
      )}

      <div className="mb-4">
        <div className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-semibold mb-3">
          {pkg.genderTag}
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
      </div>

      <div className="mb-6">
        <div className="flex items-baseline space-x-2 mb-1">
          <span className="text-4xl font-bold text-gray-900">₹{pkg.offerPrice}</span>
          <span className="text-lg text-gray-400 line-through">₹{pkg.originalPrice}</span>
        </div>
        <div className="inline-block bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-semibold">
          Save {discount}%
        </div>
      </div>

      <div className="mb-6 space-y-3">
        {pkg.bullets.map((bullet, idx) => (
          <div key={idx} className="flex items-start space-x-2">
            <div className="flex-shrink-0 w-5 h-5 bg-blue-100 rounded-full flex items-center justify-center mt-0.5">
              <Check className="w-3 h-3 text-blue-600" />
            </div>
            <span className="text-gray-700 text-sm leading-relaxed">{bullet}</span>
          </div>
        ))}
      </div>

      <button
        onClick={() => onBook(pkg)}
        className={`w-full py-3 rounded-lg font-semibold transition-all ${
          pkg.popular
            ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-600 hover:to-orange-700 shadow-md hover:shadow-lg'
            : 'bg-blue-600 text-white hover:bg-blue-700'
        }`}
      >
        Book Now
      </button>
    </motion.div>
  );
}
