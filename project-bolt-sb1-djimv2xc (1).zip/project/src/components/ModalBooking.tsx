import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { submitBooking, BookingData } from '../utils/api';
import { Package } from '../data/packages';

const bookingSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  phone: z.string().regex(/^[6-9]\d{9}$/, 'Enter valid 10-digit mobile number'),
  email: z.string().email('Enter valid email address'),
  preferredDate: z.string().min(1, 'Please select a date'),
  preferredTime: z.string().min(1, 'Please select a time'),
  notes: z.string().optional()
});

type BookingFormData = z.infer<typeof bookingSchema>;

interface ModalBookingProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPackage: Package | null;
}

export default function ModalBooking({ isOpen, onClose, selectedPackage }: ModalBookingProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [submitMessage, setSubmitMessage] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema)
  });

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setSubmitStatus('idle');
      setSubmitMessage('');
    } else {
      document.body.style.overflow = 'unset';
      reset();
    }
  }, [isOpen, reset]);

  const onSubmit = async (data: BookingFormData) => {
    if (!selectedPackage) return;

    setIsSubmitting(true);
    setSubmitStatus('idle');

    const bookingData: BookingData = {
      ...data,
      packageId: selectedPackage.id,
      packageName: selectedPackage.name
    };

    try {
      const response = await submitBooking(bookingData);
      setSubmitStatus(response.success ? 'success' : 'error');
      setSubmitMessage(response.message);

      if (response.success) {
        setTimeout(() => {
          onClose();
        }, 3000);
      }
    } catch {
      setSubmitStatus('error');
      setSubmitMessage('An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <AnimatePresence>
      {isOpen && selectedPackage && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 flex justify-between items-start">
                <div>
                  <h2 className="text-2xl font-bold mb-1">Book Your Appointment</h2>
                  <p className="text-blue-100">{selectedPackage.name} ({selectedPackage.genderTag})</p>
                  <p className="text-xl font-semibold mt-2">₹{selectedPackage.offerPrice}</p>
                </div>
                <button
                  onClick={onClose}
                  className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
                  aria-label="Close modal"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-6">
                {submitStatus === 'success' ? (
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="text-center py-8"
                  >
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h3>
                    <p className="text-gray-600">{submitMessage}</p>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-1">
                        Full Name *
                      </label>
                      <input
                        {...register('name')}
                        type="text"
                        id="name"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Enter your full name"
                      />
                      {errors.name && (
                        <p className="text-red-600 text-sm mt-1" role="alert">{errors.name.message}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-1">
                        Mobile Number *
                      </label>
                      <input
                        {...register('phone')}
                        type="tel"
                        id="phone"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="9876543210"
                      />
                      {errors.phone && (
                        <p className="text-red-600 text-sm mt-1" role="alert">{errors.phone.message}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-1">
                        Email Address *
                      </label>
                      <input
                        {...register('email')}
                        type="email"
                        id="email"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="your@email.com"
                      />
                      {errors.email && (
                        <p className="text-red-600 text-sm mt-1" role="alert">{errors.email.message}</p>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="preferredDate" className="block text-sm font-semibold text-gray-700 mb-1">
                          Preferred Date *
                        </label>
                        <input
                          {...register('preferredDate')}
                          type="date"
                          id="preferredDate"
                          min={today}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        {errors.preferredDate && (
                          <p className="text-red-600 text-sm mt-1" role="alert">{errors.preferredDate.message}</p>
                        )}
                      </div>

                      <div>
                        <label htmlFor="preferredTime" className="block text-sm font-semibold text-gray-700 mb-1">
                          Preferred Time *
                        </label>
                        <select
                          {...register('preferredTime')}
                          id="preferredTime"
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        >
                          <option value="">Select time</option>
                          <option value="08:00-10:00">08:00 - 10:00 AM</option>
                          <option value="10:00-12:00">10:00 - 12:00 PM</option>
                          <option value="12:00-14:00">12:00 - 02:00 PM</option>
                          <option value="14:00-16:00">02:00 - 04:00 PM</option>
                          <option value="16:00-18:00">04:00 - 06:00 PM</option>
                        </select>
                        {errors.preferredTime && (
                          <p className="text-red-600 text-sm mt-1" role="alert">{errors.preferredTime.message}</p>
                        )}
                      </div>
                    </div>

                    <div>
                      <label htmlFor="notes" className="block text-sm font-semibold text-gray-700 mb-1">
                        Additional Notes (Optional)
                      </label>
                      <textarea
                        {...register('notes')}
                        id="notes"
                        rows={3}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                        placeholder="Any special requirements or questions?"
                      />
                    </div>

                    {submitStatus === 'error' && (
                      <div className="flex items-center space-x-2 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                        <AlertCircle className="w-5 h-5 flex-shrink-0" />
                        <p className="text-sm">{submitMessage}</p>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white px-6 py-4 rounded-lg hover:from-orange-600 hover:to-orange-700 transition-all font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          <span>Processing...</span>
                        </>
                      ) : (
                        <span>Confirm Booking</span>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
