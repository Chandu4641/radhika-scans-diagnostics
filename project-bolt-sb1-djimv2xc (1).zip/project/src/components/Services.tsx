import { motion } from 'framer-motion';
import { Award, Users, Microscope, IndianRupee } from 'lucide-react';

const services = [
  {
    icon: Award,
    title: 'Accurate Reports',
    description: 'NABL accredited lab ensuring precise and reliable diagnostic results'
  },
  {
    icon: Users,
    title: 'Experienced Team',
    description: 'Skilled technicians and pathologists with years of expertise'
  },
  {
    icon: Microscope,
    title: 'Modern Equipment',
    description: 'State-of-the-art technology for advanced diagnostic testing'
  },
  {
    icon: IndianRupee,
    title: 'Affordable Pricing',
    description: 'Quality healthcare at competitive prices with regular offers'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Why Choose Us?
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            We combine cutting-edge technology with compassionate care to deliver the best diagnostic services
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -8, transition: { duration: 0.2 } }}
              className="text-center p-6 rounded-xl hover:shadow-lg transition-all"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl mb-4 shadow-lg">
                <service.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
